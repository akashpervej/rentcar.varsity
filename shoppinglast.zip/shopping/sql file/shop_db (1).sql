-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 24, 2023 at 10:56 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_order`
--

CREATE TABLE `admin_order` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `name`, `price`, `image`, `quantity`) VALUES
(20, 'BMW X6', '900', 'BMW_x6.png', 1),
(21, 'tronto', '100', '2021 Toronto-m30.png', 1),
(22, 'yamaha', '800', 'yamaha-mt-07.jpg', 1),
(24, 'BMW X6	', '2700', 'BMW_x6.png', 1),
(25, 'Ford', '2400', 'Ford F-150.jpg', 2);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` varchar(700) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `subject`, `message`) VALUES
(1, 'Abdul Sajid', 'sajidahmed7771@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', 'd41d8cd98f00b204e9800998ecf8427e'),
(2, 'Abdul Sajid45', 'sajidahmed7271@gmail.com', 'ds', 'sdff'),
(3, 'Sajid', 'sajidahmed7771@gmail.com', 'asas', 'weew'),
(4, 'robin', 'sajidahmed7771@gmail.comfd', 'err', 'fdfd'),
(5, 'robin', 'sajidahmed7377@gmail.com', 'fg', 'frr');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `number` varchar(12) NOT NULL,
  `email` varchar(255) NOT NULL,
  `method` varchar(100) NOT NULL,
  `flat` varchar(100) NOT NULL,
  `street` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `pin_code` int(10) NOT NULL,
  `total_products` varchar(255) NOT NULL,
  `total_price` varchar(255) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `name`, `number`, `email`, `method`, `flat`, `street`, `city`, `state`, `country`, `pin_code`, `total_products`, `total_price`, `status`) VALUES
(1, 'Abdul Sajid', '01675227644', 'sajidahmed7771@gmail.com', 'paypal', 'Mirpur-1216,Savar,Dhaka', 'nsaidsd', 'Dhaka', 'Mirpur', 'Bangladesh', 1216, 'BMW X6 (2) ', '512', ''),
(2, 'Abdul Sajid', '01456622', 'sajidahmed7771@gmail.com', 'paypal', 'Mirpur-1216,Savar,Dhaka', 'Mirpur-1216,Savar,Dhaka', '2023-08-15', '2023-08-17', 'Bangladesh', 0, 'BMW X6 (2) ', '512', ''),
(3, 'Abdul Sajid', '25241', 'sajidahmed7771@gmail.com', 'paypal', 'Mirpur-1216,Savar,Dhaka', 'Mirpur-1216,Savar,Dhaka', '2023-08-03', '2023-08-17', 'Bangladesh', 0, 'BMW X6 (2) ', '512', ''),
(4, 'Abdul Sajid', '2442', 'sajidahmed7771@gmail.com', 'paypal', 'Mirpur-1216,Savar,Dhaka', 'Mirpur-1216,Savar,Dhaka', '2023-08-15', '2023-08-23', 'Bangladesh', 0, 'BMW X6 (3) ', '768', ''),
(5, 'Abdul Sajid', '027552', 'sajidahmed7771@gmail.com', 'paypal', '52', 'Mirpur-1216,Savar,Dhaka', '2023-08-17', '2023-08-25', 'Bangladesh', 0, 'BMW X6 (3) , bmf (1) ', '770', ''),
(6, 'Abdul Sajid', '015', 'sajidahmed7771@gmail.com', 'Non-driver', 'Mirpur-1216,Savar,Dhaka', 'Mirpur-1216,Savar,Dhaka', '2023-08-25', '2023-08-08', '', 1216, 'BMW X6 (1) , toronto (2) ', '456', ''),
(7, 'Abdul Sajid', '042142', 'sajidahmed7771@gmail.com', 'approved', 'Mirpur-1216,Savar,Dhaka', 'Mirpur-1216,Savar,Dhaka', '2023-08-12', '2023-08-26', '', 1216, 'BMW X6 (1) , toronto (2) ', '456', ''),
(10, 'Abdul Sajid45', '45', 'sajidahmed7771@gmail.com', 'bkash', 'Mirpur-1216,Savar,Dhaka', 'Mirpur-1216,Savar,Dhaka', '2023-08-11', '2023-07-31', 'Non-driver', 1216, 'BMW X6 (1) , toronto (2) ', '456', ''),
(12, 'Abdul Sajid', '2', 'sajidahmed7771@gmail.com', 'approved', 'Mirpur-1216,Savar,Dhaka', 'Mirpur-1216,Savar,Dhaka', '2023-08-25', '2023-08-24', 'Non-driver', 0, 'BMW X6 (1) , tronto (1) ', '1000', ''),
(20, 'Azharul', '01711111111', 'azrail@gmail.com', 'approved', 'dhaka', 'Mirpur', '2023-08-25', '2023-08-27', 'Driver', 1216, 'BMW X6 (2) , tronto (1) , yamaha (1) , BMW X6	 (1) ', '5400', ''),
(21, 'Jishan', '01585468500', 'jishan@gmail.com', 'approved', 'dhaka', 'narayanganj', '2023-08-25', '2023-08-29', 'Driver', 1216, 'BMW X6 (2) , tronto (1) , yamaha (1) , BMW X6	 (1) , Ford (1) ', '7800', '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `image`) VALUES
(865, 'BMW X6	', '2700', 'BMW_x6.png'),
(958, 'Yamaha', '1010', 'yamaha-mt-07.jpg'),
(248, 'Ford', '2400', 'Ford F-150.jpg'),
(775, 'Tronto', '100', '2021 Toronto-m30.png');

-- --------------------------------------------------------

--
-- Table structure for table `user_form`
--

CREATE TABLE `user_form` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_form`
--

INSERT INTO `user_form` (`id`, `name`, `email`, `password`, `user_type`) VALUES
(1, 'Abdul Sajid', 'sajidahmed7771@gmail.com', 'c20ad4d76fe97759aa27a0c99bff6710', 'user'),
(2, 'Sajid', 'sajidahmed7776@gmail.com', '202cb962ac59075b964b07152d234b70', 'admin'),
(3, 'sodf', 'sajidahmed7771@gmail.co', '202cb962ac59075b964b07152d234b70', 'user'),
(4, 'abid', 'abida@gmail', '202cb962ac59075b964b07152d234b70', 'user'),
(5, 'Yes-Débarras', 'akashmh100@gmail.com', '$2y$10$hkdRTYw5WFyvPOufGQdz4.5C75afhgqnwnkf/l.OFbs3XyjA9/M3O', 'user'),
(6, 'Yes-Débarras', 'yesdebarras@outlook.com', '$2y$10$q79ggjMvvg279l/pYqfBVO1qVscMtSlguatrcGNt1EFmKgYBsWChi', 'user'),
(7, 'Yes-Débarras', 'akashmh900@gmail.com', '$2y$10$nT/DwRspkj7MzpMjwJkZ4OhkeQF9D.Vpfzy97RZeloX6LcW79ZaW6', 'user'),
(8, 'Yes-Débarras', 'akashmh10@edu.bd', '$2y$10$xUpfyeHa2aS0yyhbhD6s0.Y/82WfCnkMes5IGwbmsOV10nSaVIqYy', 'user'),
(9, 'PANNA', 'panna@gmail.com', '$2y$10$5A8bYw7X7d.l8VDnv2E8D.rmmRZ6N7jmlQw1eHp3WvR5otq.6qSXu', 'user'),
(10, 'MD.AKASH PERVEJ', 'akashmh10@gmail.com', '$2y$10$a76oXQOz4kfUVKcKIyb0ieMicqAttSH9oVXUhu9tnWA.cTDNqlSim', 'user'),
(11, 'Jishan', 'jisan@gmail.com', '$2y$10$bV535YTaQWS0i121VSbcdO.NaACZQwV97/PCBn.aP/K2oz1yA40ry', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_order`
--
ALTER TABLE `admin_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_form`
--
ALTER TABLE `user_form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_order`
--
ALTER TABLE `admin_order`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `user_form`
--
ALTER TABLE `user_form`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
