<?php


@include 'config.php';

if(isset($_POST['submit'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = mysqli_real_escape_string($conn, $_POST['subject']);
   $cpass = mysqli_real_escape_string($conn, $_POST['message']);
   
  

   $select = " SELECT * FROM contact WHERE email = '$email' && name = '$name' ";

   $result = mysqli_query($conn, $select);

   if(mysqli_num_rows($result) > 0){

    $error[] = 'message sent';
 }

else{
       $insert = "INSERT INTO contact(name, email, subject, message) VALUES('$name','$email','$pass','$cpass')";
       mysqli_query($conn, $insert);
      
    }
 

};


?>



<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Contact Us</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="cse/styl.css">

   <link rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

</head>
<body>
<?php include 'header.php'; ?>
<section class="contactheader">
    <div class="headings" style="background:url(img/abot.jpg)" no-repeat>
        <h1>Contact Us</h1>
    </div>
    </section>
<div class="form-container">

   <form action="" method="post">
      <h3>Contact Us</h3>
      <?php
      if(isset($error)){
         foreach($error as $error){
            echo '<span class="error-msg">'.$error.'</span>';
         };
      };
      ?>
      
      <input type="text" name="name" required placeholder="enter your name">
      <input type="email" name="email" required placeholder="enter your email">
      <input type="text" name="subject" required placeholder="subject(Vehicle name if you want to give rent)">
      <input type="text" name="message" placeholder="Your message ">
      
      <input type="submit" name="submit" value="Submit" class="form-btn">
    
   </form>

</div>

<footer class="footer">
        <div class="form-containers">
            <div class="row">
                <div class="footer-col">
                    <h4>company</h4>
                    <ul>
                        <li><a href="#">about us</a></li>
                        <li><a href="#">our services</a></li>
                        <li><a href="#">privacy policy</a></li>
                        <li><a href="#">reviews</a></li>
                            
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>get help</h4>
                    <ul>
                        <li><a href="#">FAQ</a></li>
                        <li><a href="#">Shipping</a></li>
                        <li><a href="#">returns</a></li>  
                        <li><a href="#">order status</a></li>
                        <li><a href="#">payment option</a></li>                
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>online order</h4>
                    <ul>
                        <li><a href="#">cars</a></li>
                        <li><a href="#">cycle</a></li>
                        <li><a href="#">motorcycle </a></li>
                        <li><a href="#">truck</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>follow us</h4>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                </div>
            </div>
        </div>
    </footer>





</body>
</html>