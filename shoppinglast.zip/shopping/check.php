<?php
@include 'config.php';

if (isset($_GET['action']) && isset($_GET['id'])) {
   $action = $_GET['action'];
   $order_id = $_GET['id'];

   if ($action === 'approve') {
      mysqli_query($conn, "UPDATE `order` SET method = 'approved' WHERE id = $order_id");
   } elseif ($action === 'delete') {
      mysqli_query($conn, "DELETE FROM `order` WHERE id = $order_id");
   }

   header('Location: check.php');
   exit();
}

$unverified_orders_query = mysqli_query($conn, "SELECT * FROM `order` WHERE method = 'cash on delivery'");

$approved_users_query = mysqli_query($conn, "SELECT * FROM `order` WHERE method = 'approved'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Order Verification</title>

   
   <link rel="stylesheet" href="css/style.css">
   <style>
  table {
    border: 1px solid black; 
    border-collapse: collapse; 
    font-size: medium;
  }
  th {
    font-weight: bold;
  }
  th, td {
    border: 1px solid black;
  }
  .btn {
    display: inline-block;
    padding: 5px 5px;
    background-color: #007bff;
    color: whitesmoke;
    border: none;
    border-radius: 2px;
    font-size: 8px;
    cursor: pointer;
    font-size: medium;
    
  }


  .btn:hover {
    background-color: #0056b3;
  }
  h2{
    margin: 5px;
  }
  h1{
    margin: 5px;
  }
  .h2 {
    size: 30px;
    color: #007bff;
    box-sizing: border-box;
    padding: 15px 15px;
    border: 1px solid black; 
    border-collapse: collapse;
  }
</style>
</head>
<body>



<div class="container">
   <h1 class="h2">Pending Orders</h1>

   <table>
      <thead>
         <tr>
            <th>Order ID</th>
            <th>Email</th>
            <th>Address</th>
            <th>Customer Name</th>
            <th>Pick-up Location</th>
            <th>Phone Number</th>
            <th>Total Price</th>
            <th>Actions</th>
         </tr>
      </thead>
      <tbody>
         <?php while ($order = mysqli_fetch_assoc($unverified_orders_query)) { ?>
            <tr>
               <td><?php echo $order['id']; ?></td>
               <td><?php echo $order['email']; ?></td>
               <td><?php echo $order['flat']; ?></td>
               <td><?php echo $order['name']; ?></td>
               <td><?php echo $order['flat']; ?></td>
               <td><?php echo $order['number']; ?></td>
               <td><?php echo 'TK ' . $order['total_price'] . '/-'; ?></td>
               <td>
                  <a href="check.php?action=approve&id=<?php echo $order['id']; ?>" class='btn'>Approve</a>
                  <a href="check.php?action=delete&id=<?php echo $order['id']; ?> " class='btn'>Delete</a>
               </td>
            </tr>
         <?php } ?>
      </tbody>
   </table>

   <h1 class="h2">Approved Orders</h1>
   <table>
      <thead>
         <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Total Price</th>
            <th>Pick-up Location</th>
            <th>Phone Number</th>
         </tr>
      </thead>
      <tbody>
         <?php while ($user = mysqli_fetch_assoc($approved_users_query)) { ?>
            <tr>
               <td><?php echo $user['id']; ?></td>
               <td><?php echo $user['name']; ?></td>
               <td><?php echo $user['email']; ?></td>
               <td><?php echo 'TK ' . $user['total_price'] . '/-'; ?></td>
               <td><?php echo $user['flat'] . ', ' . $user['city']; ?></td>
               <td><?php echo $user['number']; ?></td>
            </tr>
         <?php } ?>
      </tbody>
   </table>
</div>



</body>
</html>
