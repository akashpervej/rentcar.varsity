<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car rent</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<header>
        <a href="#" class="logo"><img src="img/sas.jpg" alt=""></a>
        <div class="bx bx-menu" id="menu-icon"></div>

        <ul class="navbar">
            <li><a href="index.php" style="color:white">Home</a></li>
            <li><a href="about.php" style="color:white">About Us</a></li>
            <li><a href="products.php" style="color:white">Vehicles</a></li>
            <li><a href="contact.php" style="color:white">Contact Us</a></li>
            
            <?php
if(isset($_SESSION['user_name'])){
    echo '<li><a class="navb" href="index.php" style="color:white; font-size:18px">' . $_SESSION['user_name'] . '</a></li>';
    echo '<li><a class="navb" href="logout.php" style="color:white; font-size:18px">Logout</a></li>';
} else {
    echo '<li><a class="navb" href="register_form.php" style="color:white; font-size:18px">Sign Up</a></li>';
    echo '<li><a class="navb" href="login_form.php" style="color:white; font-size:18px">Sign In</a></li>';
}
?>

          
            <li><a href="cart.php" style="color:white">Cart</a></li>
            <li><div id="menu-btn" class="fas fa-bars"></div></li>
        </ul>

        <div class="header-btn">
            
        </div>
</header>

<section class="home" id="home">
  
    <?php
    if(isset($_SESSION['success_message'])){
        echo '<div class="success-message">'.$_SESSION['success_message'].'</div>';
        unset($_SESSION['success_message']);
    }
    ?>
</section>

     <!--ride-->

     <section class="ride" id="ride">
        <div class="heading">
            <span>How Its Work</span>
            <h1>Rent With 3 Easy Steps</h1>
        </div>
       <div class="ride-container">
        <div class="box">
            <i class='bx bxs-map'></i>
            
            <h2 style="color:rgb(15, 87, 230);" >Choose a location</h2>
            <p>Decide where you want to rent the car from. This could be an airport, a city location, or a specific rental agency. Consider factors like convenience, proximity to your destination, and availability of rental options.</p>

        </div>

        <div class="box">
            <i class='bx bxs-calendar-check'></i>
           
            <h2 style="color:rgb(15, 87, 230);">Pick-Up Date</h2>
            <p>Select the date and time when you want to pick up the car. Make sure to plan ahead and consider your travel itinerary to determine the most suitable pick-up time. Keep in mind that popular travel seasons or weekends may have higher demand.</p>
         </div>

        <div class="box">
            <i class='bx bxs-calendar-star' ></i>
        
            <h2 style="color:rgb(15, 87, 230);">Book A Car</h2>
            <p>Once you have chosen the location and pick-up date, it's time to book a car. There are several ways to do this.Visit the website of a reputable car rental company or use a car rental aggregator platform. </p>
        </div>
        </div>
    </section>

    <!-- Services-->
    <section class="services" id="services">
        <div class="heading">
            <span>Best Services</span>
            <h1 style="color:rgb(0, 225, 255);">Explore Out Top Deals </h1>
            <h1 style="color: blue;"> From Top Rated Dealers</h1>
        </div>
        
        <div class="services-container">
            <div class="box">
                <div class="box-img">
                    <img src="img/x6.webp" alt="">
                </div>
                <p>2014</p>
                <h3>2014 BMW X6</h3>
                <h2>Best Vehicle to Drive <span>/Try</span> </h2>
                <a href="#" class="btn">Rent Now</a>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="img/BMW_i5.jpg" alt="">
                </div>
                <p>2023</p>
                <h3>2023 BMW i5</h3>
                <h2>Best Vehicle to Drive <span>/Try</span> </h2>
                <a href="#" class="btn">Rent Now</a>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="img/Tata-Nexon.jpg" alt="">
                </div>
                <p>2020</p>
                <h3>2020 Tata Nexonhonda</h3>
                <h2>Best Vehicle to Drive <span>/Try</span> </h2>
                <a href="#" class="btn">Rent Now</a>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="img/yamaha-mt-07.webp" alt="">
                </div>
                <p>2021</p>
                <h3>2021 Yamaha mt 07</h3>
                <h2>Best Vehicle to Drive <span>/Try</span> </h2>
                <a href="#" class="btn">Rent Now</a>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="img/Honda CB500X.jpg" alt="">
                </div>
                <p>2022</p>
                <h3>2022 Honda CB500X</h3>
                <h2>Best Vehicle to Drive <span>/Try</span> </h2>
                <a href="#" class="btn">Rent Now</a>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="img/trek fx 1.webp" alt="">
                </div>
                <p>2021</p>
                <h3>2021 Trek FX 1</h3>
                <h2>Best Vehicle to Drive <span>/Try</span> </h2>
                <a href="#" class="btn">Rent Now</a>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="img/toronto-m30.webp" alt="">
                </div>
                <p>2021</p>
                <h3>2021 Toronto-m30</h3>
                <h2>Best Vehicle to Drive <span>/Try</span> </h2>
                <a href="#" class="btn">Rent Now</a>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="img/Chevrolet-Cruze.jpg" alt="">
                </div>
                <p>2016</p>
                <h3>2016 Chevrolet Cruze</h3>
                <h2>Best Vehicle to Drive <span>/Try</span> </h2>
                <a href="#" class="btn">Rent Now</a>
            </div>
            <div class="box">
                <div class="box-img">
                    <img src="img/2019-nissan-altima.webp" alt="">
                </div>
                <p>2019</p>
                <h3>2019 Nissan Altima</h3>
                <h2>Best Vehicle to Drive <span>/Try</span> </h2>
                <a href="#" class="btn">Rent Now</a>
            </div>
            <div class="box">
                <div class="box-img">
                    <img src="img/Ford F-150.webp" alt="">
                </div>
                <p>2023</p>
                <h3>2023 Ford F-150</h3>
                <h2>Best Vehicle to Drive <span>/Try</span> </h2>
                <a href="#" class="btn">Rent Now</a>
            </div>

        </div>

    </section>

    <!-- About -->
    <section class="about" id="about">
        <div class="heading">
            <span>About Us</span>
            <h1>Best Cutomer Experience</h1>
            
        </div>
        <div  class="about-container">
            <div class="about-img">
                <img src="img/about.png" alt="">
            </div>
            <div class="about-text">
                <span> About Us</span>
                <p>We understand the importance of having a hassle-free and enjoyable travel experience. Whether you're a frequent traveler, a family going on vacation, or a business professional attending meetings, we aim to make your journey comfortable and convenient with our wide range of rental vehicles.</p>
                <p> <h4>Our Mission:</h4>
                    
                    Our mission is to be your trusted partner in transportation by offering high-quality rental vehicles, exceptional customer service, and competitive prices. We believe that renting a car should be a seamless and straightforward process, providing you with the freedom and flexibility to explore your destination at your own pace.</p>
                <a href="#" class="btn">Learn More</a>
            </div>
        </div>
    </section>

    <!-- Reviews -->
    <section class="reviews" id="reviews">
        <div class="heading">
            <span>Reviews</span>
            <h1>Whats Our Customer Say</h1>
        </div>
        <div class="reviews-container">
            <div class="box">
                <div class="rev-img">
                    <img src="img/tan.jpg" alt="">

                </div>
                <h2>Tanvir Rahman</h2>
                <div class="stars">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star-half' ></i>
                </div>
                <p>"I rented a car from this website for my family vacation, and I couldn't be happier with the service. The booking process was smooth, and the vehicle was clean and in excellent condition. The staff was friendly and professional, and they even provided helpful tips for exploring the area. I highly recommend this website for their reliable and customer-oriented approach."</p>
            </div>

            <div class="box">
                <div class="rev-img">
                    <img src="img/sakil.jpg" alt="">

                </div>
                <h2>Sakil Ahmed</h2>
                <div class="stars">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star-half' ></i>
                </div>
                <p>"I've been renting cars from this website for several years, and they have consistently exceeded my expectations. Their fleet is always well-maintained, and the vehicles are reliable. The prices are competitive, and the customer service is top-notch. I appreciate their flexibility with pick-up and drop-off times, which makes planning my trips much easier. I highly recommend this website to anyone in need of a rental car."</p>
            </div>

            <div class="box">
                <div class="rev-img">
                    <img src="img/Jannat.jpg" alt="">

                </div>
                <h2>Janntaul Mou</h2>
                <div class="stars">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star-half' ></i>
                </div>
                <p>"I had a last-minute business trip and needed a rental car urgently. I found website online and decided to give them a try. I was pleasantly surprised by their prompt response and their ability to accommodate my request on short notice. The car was ready when I arrived, and the whole process was seamless. I appreciate their efficiency and would definitely use their services again."</p>
            </div>

        </div>
    </section>

    <!-- NewsLetter-->
    <section class="newsletter">
        <h2>Subscribe To SAS</h2>
        <div class="box">
            <input type="text" placeholder="Enter Your Email...">
            <a href="#" class="btn">Subscribe</a>
        </div>
    </section>
    <div class="copyright">
        <p>&#163;  All Right Reserved</p>
        <div class="social">
            <a href="#"><i class='bx bxl-facebook' ></i></a>
            <a href="#"><i class='bx bxl-twitter' ></i></a>
            <a href="#"><i class='bx bxl-instagram' ></i></a>
        </div>
    </div>

    <footer class="footer">
        <div class="form-container">
            <div class="row">
                <div class="footer-col">
                    <h4>company</h4>
                    <ul>
                        <li><a href="#">about us</a></li>
                        <li><a href="#">our services</a></li>
                        <li><a href="#">privacy policy</a></li>
                        <li><a href="#">reviews</a></li>
                            
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>get help</h4>
                    <ul>
                        <li><a href="#">FAQ</a></li>
                        <li><a href="#">Shipping</a></li>
                        <li><a href="#">returns</a></li>  
                        <li><a href="#">order status</a></li>
                        <li><a href="#">payment option</a></li>                
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>online order</h4>
                    <ul>
                        <li><a href="#">cars</a></li>
                        <li><a href="#">cycle</a></li>
                        <li><a href="#">motorcycle </a></li>
                        <li><a href="#">truck</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>follow us</h4>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="js/script.js"></script>
    
</body>
</html>