<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car rent</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<header>
        <a href="#" class="logo"><img src="img/sas.jpg" alt=""></a>
        <div class="bx bx-menu" id="menu-icon"></div>

        <ul class="navbar">
            <li><a class="navb" href="index.php" style="color:white; font-size:18px">Home</a></li>
            <li><a class="navb" href="about.php" style="color:white; font-size:18px">About Us</a></li>
            <li><a class="navb" href="products.php" style="color:white; font-size:18px">Vehicles</a></li>
            <li><a class="navb" href="contact.php" style="color:white; font-size:18px">Contact Us</a></li>
            
            <?php
if(isset($_SESSION['user_name'])){
    echo '<li><a class="navb" href="index.php" style="color:white; font-size:18px">' . $_SESSION['user_name'] . '</a></li>';
    echo '<li><a class="navb" href="logout.php" style="color:white; font-size:18px">Logout</a></li>';
} else {
    echo '<li><a class="navb" href="register_form.php" style="color:white; font-size:18px">Sign Up</a></li>';
    echo '<li><a class="navb" href="login_form.php" style="color:white; font-size:18px">Sign In</a></li>';
}
?>

          
            <li><a class="navb" href="cart.php" style="color:white; font-size:18px">Cart</a></li>
            <li><div id="menu-btn" class="fas fa-bars"></div></li>
        </ul>

        <div class="header-btn">
            
        </div>
</header>


