<?php
session_start();

include 'config.php';

$errors = array();

if(isset($_POST['submit'])){
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $password = $_POST['password'];

   $select = "SELECT * FROM user_form WHERE email = '$email'";
   $result = mysqli_query($conn, $select);

   if(mysqli_num_rows($result) > 0){
      $row = mysqli_fetch_assoc($result);
      if(password_verify($password, $row['password'])){
         $_SESSION['user_name'] = $row['name'];
         if($row['user_type'] == 'admin'){
            header('location: admin.php');
         } elseif($row['user_type'] == 'user'){
            header('location: index.php');
         }
      } else {
         $errors[] = 'Incorrect email or password!';
      }
   } else {
      $errors[] = 'Incorrect email or password!';
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login Form</title>
   <link rel="stylesheet" href="cs/sty.css"> <!-- Include your CSS stylesheet -->
   
</head>
<body>
   
<div class="form-container">
   <form action="" method="post">
      <?php
      if(isset($_SESSION['success_message'])){
         echo '<h1 class="success-msg" style="color:green";>'.$_SESSION['success_message'].'</h1>';
         unset($_SESSION['success_message']);
      }
      ?>
      <h3>Login Now</h3>
      <?php
      if(isset($errors)){
         foreach($errors as $error){
            echo '<span class="error-msg">'.$error.'</span>';
         }
      }
      ?>
      <input type="email" name="email" required placeholder="Enter your email">
      <input type="password" name="password" required placeholder="Enter your password">
      <input type="submit" name="submit" style="color:white;" value="Login Now" class="form-btn">
      <p>Don't have an account? <a href="register_form.php">Register now</a></p>
   </form>
</div>

</body>
</html>
