<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>About Us</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="cse/styl.css">

   <link rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

</head>
<body>
<?php include 'header.php'; ?>


<section>
    <div class="headings" style="background:url(img/abot.jpg)" no-repeat>
        <h1>About Us</h1>
    </div>
    </section>

     <section class="abouts">
        <div class="image">
            <img src="img/trek fx 1.webp" alt="">
        </div>
            <div class="content">
                <h3>Why choose us?</h3>
                <p>We are popular car rental agency in Bangladesh. we offer all type of car with cheap price, and on time every trip. Daily, Weekly, Monthly, Yearly all package are available.
                    We provide all type of car rental service for daily, Weekly, Monthly and Yearly . All car are available here. If you need rent a car service contact us
                    We Providing multiple pickup and drop-off locations, including airports and popular tourist spots, can make it convenient for customers to access your rental service.
                    customers will find it convenient to browse and book vehicles, enhancing their overall experience.
                    </p>
                <p>Incorporating eco-friendly vehicle options or sustainability practices can attract environmentally conscious customers and align with current trends.Regularly seeking customer feedback and making improvements based on their suggestions can showcase your commitment to enhancing the user experience.</p>
                <p></p>
                
        </div>
     </section>

     <footer class="footer">
        <div class="form-containers">
            <div class="row">
                <div class="footer-col">
                    <h4>company</h4>
                    <ul>
                        <li><a href="#">about us</a></li>
                        <li><a href="#">our services</a></li>
                        <li><a href="#">privacy policy</a></li>
                        <li><a href="#">reviews</a></li>
                            
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>get help</h4>
                    <ul>
                        <li><a href="#">FAQ</a></li>
                        <li><a href="#">Shipping</a></li>
                        <li><a href="#">returns</a></li>  
                        <li><a href="#">order status</a></li>
                        <li><a href="#">payment option</a></li>                
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>online order</h4>
                    <ul>
                        <li><a href="#">cars</a></li>
                        <li><a href="#">cycle</a></li>
                        <li><a href="#">motorcycle </a></li>
                        <li><a href="#">truck</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>follow us</h4>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                </div>
            </div>
        </div>
    </footer>

    </body>
    </html>
