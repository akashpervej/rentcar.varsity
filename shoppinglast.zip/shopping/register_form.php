<?php
session_start();

include 'config.php';

$errors = array();

if(isset($_POST['submit'])){
   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $password = $_POST['password'];
   $cpassword = $_POST['cpassword'];
   $user_type = $_POST['user_type'];

   // Validate inputs
   if(empty($name) || empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL) || empty($password) || empty($cpassword) || $password !== $cpassword){
      $errors[] = 'Please fill in all fields correctly.';
   } else {
      $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Use bcrypt for secure password hashing
      
      $select = "SELECT * FROM user_form WHERE email = '$email'";
      $result = mysqli_query($conn, $select);

      if(mysqli_num_rows($result) > 0){
         $errors[] = 'User already exists!';
      } else {
         $insert = "INSERT INTO user_form(name, email, password, user_type) VALUES('$name', '$email', '$hashed_password', '$user_type')";
         mysqli_query($conn, $insert);
         $_SESSION['success_message'] = 'Registered successfully! Please log in.';
         header('location: login_form.php');
         exit();
      }
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register Form</title>
   <link rel="stylesheet" href="cs/sty.css"> 
</head>
<body>
   
<div class="form-container">
   <form action="" method="post">
      <h3>Register Now</h3>
      <?php
      if(isset($errors)){
         foreach($errors as $error){
            echo '<span class="error-msg">'.$error.'</span>';
         }
      }
      ?>
      <?php
      if(isset($_SESSION['success_message'])){
         echo '<span class="success-msg">'.$_SESSION['success_message'].'</span>';
         unset($_SESSION['success_message']);
      }
      ?>
      <input type="text" name="name" required placeholder="Enter your name">
      <input type="email" name="email" required placeholder="Enter your email">
      <input type="password" name="password" required placeholder="Enter your password">
      <input type="password" name="cpassword" required placeholder="Confirm your password">
      <select name="user_type">
         <option value="user">User</option>
         <option value="admin">Admin</option>
      </select>
      <input type="submit" name="submit" style="color:white;" value="Register Now" class="form-btn">
      <p>Already have an account? <a href="login_form.php">Login now</a></p>
   </form>
</div>

</body>
</html>
