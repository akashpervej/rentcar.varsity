<?php
include 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $customerName = $_POST['customer_name'];
    $product = $_POST['product'];

    $sql = "INSERT INTO order (customer_name, product, status) VALUES ('$customerName', '$product', 'Pending')";
    $conn->query($sql);
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h2>Place an Order</h2>
    <form method="post" action="">
        <label for="customer_name">Customer Name:</label>
        <input type="text" name="customer_name" required><br>
        <label for="product">Product:</label>
        <input type="text" name="product" required><br>
        <button type="submit">Place Order</button>
    </form>
</body>
</html>
